import React,{useState} from 'react';
import styled, {ThemeProvider} from 'styled-components/native';
import theme from './theme';
import { StatusBar, Dimensions } from 'react-native';
import Input from './component/Input';
// import { images } from './images';
// import IconButton from './component/IconButton';
import Task from './component/Task';



const Container = styled.View`
  flex: 1;
  background-color: ${({theme})=>theme.background};
  justify-content: flex-start;
  align-items: center;
`;
const Title = styled.Text`
  font-size: 40px;
  font-weight: 600;
  color: ${({theme})=>theme.main};
  align-self: flex-start;
  margin: 0 20px;
`;
const List = styled.ScrollView`
  flex: 1;
  width: ${({width}) => width - 40}px;
  
`;
// const tempData = {
//   '1': { id: '1', text: 'todo 1', completed: false},
//   '2': { id: '2', text: 'todo 2', completed: true},
//   '3': { id: '3', text: 'todo 3', completed: false},
//   '4': { id: '4', text: 'todo 4', completed: false},
//   '5': { id: '5', text: 'todo 5', completed: false},
//   '6': { id: '6', text: 'todo 6', completed: false},
//   '7': { id: '7', text: 'todo 7', completed: false},
// }
export default function App() {
  const width = Dimensions.get('window').width;
  const [newTask, setNewTask] = useState('');
  const [tasks, setTasks] = useState('');
  const _addTask = () => {
    // alert(`Add: ${newTask}`);
    const ID = Date.now().toString();
    // const ID = Symbol();

    const newTaskObject = {
      [ID]: { id: ID, text: newTask, completed: false},
    };

    setNewTask('');
    setTasks({ ...tasks, ...newTaskObject }); //스프레드로 객체 합성
  };
  const _handleTextChange = text => {
    // alert('입력중');
    setNewTask(text);
  }
  const _deleteTask = (id) => {
    // delete tasks[id];  //직접 삭제할 수 없다. setter를 통해..
    const currentTasks = {...tasks};  //객체 복사
    delete currentTasks[id];
    
    setTasks(currentTasks); //tasks 교체
  };
  //완료
  const _toggleTask = (id) => {
    const currentTasks = {...tasks};
    currentTasks[id]['completed'] = !currentTasks[id]['completed'];
    console.log(currentTasks[id].completed);
    setTasks(currentTasks);
  };
  //수정
  const _updateTask = task => {
    const currentTasks = {...tasks}; //객체 복사
    currentTasks[task.id] = task;
    setTasks(currentTasks);
  }
  // 입력필드에 포커스가 떠났을때
  const _onBlur = () => {
    setNewTask('');
  };
  return (
    <ThemeProvider theme={theme}>
      <Container>
        <StatusBar 
          barStyle="light-content"
          backgroundColor={theme.background}
        />
        <Title>TODO LIST</Title>  
        <Input 
          placeholder='+ Add a Task'
          value={newTask}
          onChangeText={_handleTextChange}
          onSubmitEditing={_addTask}
          onBlur={_onBlur}
        />
        <List width={width}>
          {Object.values(tasks)
                  .reverse()
                  .map(task => (<Task 
                                  key={task.id} 
                                  task={task}
                                  // text={task.text}
                                  toggleTask={_toggleTask}
                                  updateTask={_updateTask}
                                  deleteTask={_deleteTask}
                                  onBlur={_onBlur}
                                />)
                      )
          }
        </List>
      </Container> 
    </ThemeProvider>
  );
}

